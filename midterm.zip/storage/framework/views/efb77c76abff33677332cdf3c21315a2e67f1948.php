<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage MilkTea')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
        <h1 class="text-2xl font-semibold mb-6">Edit Milk Tea</h1>
        <form method="POST" action="<?php echo e(route('milktea.update', $milktea)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="grid grid-cols-2 gap-6">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-600">Name:</label>
                    <input type="text" name="name" id="name" value="<?php echo e($milktea->name); ?>" class="mt-1 p-2 rounded-md border border-gray-300 w-full">
                </div>
                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-600">Description:</label>
                    <textarea name="description" id="description" class="mt-1 p-2 rounded-md border border-gray-300 w-full"><?php echo e($milktea->description); ?></textarea>
                </div>
                <div class="mb-4">
                    <label for="category" class="block text-sm font-medium text-gray-600">Category:</label>
                    <select name="category" id="category" class="mt-1 p-2 rounded-md border border-gray-300 w-full">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categ->id); ?>" <?php echo e($categ->id == $milktea->category->id ? 'selected' : ''); ?>>
                                <?php echo e($categ->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-4">
                    <div id="image-last" class="mb-2 text-red-500">Old Image:</div>
                    <img src="data:image/png;base64,<?php echo e(base64_encode($milktea->image)); ?>" alt="Milk Tea Image" class="w-32 h-32 object-cover border border-gray-300">
                </div>
                <div class="mb-4">
                    <label for="image" class="block text-sm font-medium text-gray-600">Image:</label>
                    <input type="file" name="image" id="image" class="mt-1 p-2 rounded-md border border-gray-300 w-full" accept="image/*" onchange="previewImage(this)">
                </div>
                <div class="mb-4 col-span-2">
                    <div id="image-message" class="mb-2 text-red-500">No Image to Preview</div>
                    <img id="image-preview" src="<?php echo e($milktea->image ? asset('images/' . $milktea->image) : 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs='); ?>" alt="Image Preview" class="w-32 h-32 object-cover border border-gray-300">
                </div>
                <div class="col-span-2 flex justify-end">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline-blue">
                        Update Milk Tea
                    </button>
                </div>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var preview = document.getElementById('image-preview');
            var message = document.getElementById('image-message');
            preview.style.display = 'none';
            message.style.display = 'block';

            function previewImage(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        preview.src = e.target.result;
                        message.style.display = 'none';
                        preview.style.display = 'block';
                    };
                    reader.readAsDataURL(input.files[0]);
                } else {
                    preview.style.display = 'none';
                    message.style.display = 'block';
                }
            }

            var imageInput = document.getElementById('image');
            imageInput.addEventListener('change', function() {
                previewImage(this);
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea/edit.blade.php ENDPATH**/ ?>