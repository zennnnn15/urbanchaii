<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Sales Report')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-8">
                <h1 class="text-4xl font-semibold mb-8">Total Sales</h1>
                <div class="flex items-center mb-6 space-x-4">
                    <label for="filter" class="text-sm font-semibold text-gray-700">Filter By:</label>
                    <select id="filter" class="px-4 py-2 border border-gray-300 rounded-md">
                        <option value="all" <?php echo e(request('filter') == 'all' ? 'selected' : ''); ?>>All</option>
                        <option value="today" <?php echo e(request('filter') == 'today' ? 'selected' : ''); ?>>Today</option>
                        <option value="week" <?php echo e(request('filter') == 'week' ? 'selected' : ''); ?>>Week</option>
                        <option value="month" <?php echo e(request('filter') == 'month' ? 'selected' : ''); ?>>Month</option>
                    </select>
                    <button id="applyFilterButton" class="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:border-blue-700 focus:ring focus:ring-blue-200" onclick="applyFilter()">Apply Filter</button>
                </div>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Milktea Size</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Quantity</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Total</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Customer</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Time</th>
                        </tr>
                    </thead>
                    <tbody id="sales-table-body">
                        <?php $__currentLoopData = $filteredSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4"><?php echo e($transaction->id); ?></td>
                                <td class="px-6 py-4"><?php echo e($transaction->milktea_size_name); ?></td>
                                <td class="px-6 py-4"><?php echo e($transaction->quantity); ?></td>
                                <td class="px-6 py-4">₱<?php echo e(number_format($transaction->total, 2)); ?></td>
                                <td class="px-6 py-4"><?php echo e($transaction->customer_name); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e(\Carbon\Carbon::parse($transaction->updated_at)->diffForHumans()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 text-xl font-semibold bg-blue-500 text-white" colspan="6">
                                Total Sales: ₱<?php echo e(number_format($totalSales, 2)); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function applyFilter() {
            const selectedFilter = document.getElementById('filter').value;
            window.location.href = `/sales/filtered?filter=${selectedFilter}`;
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/transactions/filtered.blade.php ENDPATH**/ ?>