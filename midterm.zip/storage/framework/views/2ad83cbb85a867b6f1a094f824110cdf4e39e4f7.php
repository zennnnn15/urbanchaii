<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage MilkTea')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto py-6 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 text-center">
            <?php if($milktea->image): ?>
            <img src="data:image/png;base64,<?php echo e(base64_encode($milktea->image)); ?>" alt="Milk Tea Image" class="w-32 h-32 object-cover mx-auto mb-4 rounded-full border border-gray-400">
            <?php else: ?>
            <span class="text-gray-500">No Image</span>
            <?php endif; ?>
            <h1 class="text-3xl font-semibold mb-4 text-gray-800"><?php echo e($milktea->name); ?></h1>
            <div class="mb-4">
                <p class="text-gray-700 text-lg"><strong>Description:</strong> <?php echo e($milktea->description); ?></p>
                <p class="text-gray-700 text-lg"><strong>Category:</strong> <?php echo e($milktea->category->name); ?></p>
            </div>
            <a href="<?php echo e(route('milkteasize.create', $milktea)); ?>" class="flex items-center justify-center mt-4 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded">
                <i class="fas fa-cogs mr-2"></i> Manage Available Size
            </a>
            <a href="<?php echo e(route('milkteaInSize.manage.me', $milktea)); ?>" class="flex items-center justify-center mt-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">
                <i class="fas fa-eye mr-2"></i> Show Sizes
            </a>
            <a href="<?php echo e(route('milktea.edit', $milktea)); ?>" class="flex items-center justify-center mt-4 bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded">
                <i class="fas fa-edit mr-2"></i> Edit Milk Tea
            </a>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea/show.blade.php ENDPATH**/ ?>