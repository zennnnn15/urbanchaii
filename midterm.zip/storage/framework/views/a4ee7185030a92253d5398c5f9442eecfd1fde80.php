<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Sales Report')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-3xl font-semibold mb-6">Total Sales (Status: Done)</h1>
                    <div class="mb-4">
                        <label for="filter" class="text-sm font-semibold text-gray-700">Filter By:</label>
                        <select id="filter" class="ml-2 p-2 border rounded-md">
                            <option value="today">Today</option>
                            <option value="week">Week</option>
                            <option value="month">Month</option>
                        </select>
                        <button id="applyFilterButton" class="p-2 bg-blue-500 text-white rounded-md" onclick="applyFilter()">Apply Filter</button>

                    </div>
                    
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Milktea Size</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Quantity</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Total</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Customer</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Time</th>
                            </tr>
                        </thead>
                        <tbody id="sales-table-body">
                            <?php $__currentLoopData = $totalSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4"><?php echo e($transaction->id); ?></td>
                                    <td class="px-6 py-4"><?php echo e($transaction->milktea_size_name); ?></td>
                                    <td class="px-6 py-4"><?php echo e($transaction->quantity); ?></td>
                                    <td class="px-6 py-4">₱<?php echo e(number_format($transaction->total, 2)); ?></td>
                                    <td class="px-6 py-4"><?php echo e($transaction->customer_name); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php echo e(\Carbon\Carbon::parse($transaction->updated_at)->diffForHumans()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 text-xl font-semibold bg-blue-500 text-white">
                                    Total Sales: ₱<?php echo e(number_format($totalAmount, 2)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($totalSales->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function applyFilter() {
            const selectedFilter = document.getElementById('filter').value;
            window.location.href = `/sales/filtered?filter=${selectedFilter}`;
        }
    </script>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/transactions/sold_milktea.blade.php ENDPATH**/ ?>