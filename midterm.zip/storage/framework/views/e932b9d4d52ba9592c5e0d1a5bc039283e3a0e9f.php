<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('View Order')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-3xl font-semibold mb-6">Order Details</h1>
                    <!-- Display order details -->
                    <p><strong>Order ID:</strong> <?php echo e($transactions->id); ?></p>
                    <p><strong>Milk Tea Size:</strong> <?php echo e($transactions->milktea_size_name); ?></p>
                    <p><strong>Customer Name:</strong> <?php echo e($transactions->customer_name); ?></p>
                    <p><strong>Quantity:</strong> <?php echo e($transactions->quantity); ?></p>
                    <p><strong>Total:</strong> ₱<?php echo e(number_format($transactions->total, 2)); ?></p>
                    <p><strong>Delivery Type:</strong>
                        <?php if($transactions->typeofdelivery == 1): ?>
                            Cash on Delivery
                        <?php elseif($transactions->typeofdelivery == 2): ?>
                            Pick Up
                        <?php endif; ?>
                    </p>
                    <p><strong>Status:</strong>
                        <?php if($transactions->status == 1): ?>
                            Pending
                        <?php elseif($transactions->status == 2): ?>
                            Done
                        <?php elseif($transactions->status == 3): ?>
                            Cancelled
                        <?php endif; ?>
                    </p>
                    <p><strong>Address:</strong> <?php echo e($transactions->address); ?></p>
                    <p><strong>Created At:</strong> <?php echo e($transactions->created_at); ?></p>
                    <p><strong>Updated At:</strong> <?php echo e($transactions->updated_at); ?></p>
                    
                    <!-- Map section -->
                    <div id="map" style="height: 400px; width: 100%; margin-top: 20px;"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Leaflet.js and OpenStreetMap -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

    <script>
        // Initialize and display the map
        var map = L.map('map').setView([<?php echo e($transactions->latitude); ?>, <?php echo e($transactions->longitude); ?>], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Add a marker to show the exact location
        L.marker([<?php echo e($transactions->latitude); ?>, <?php echo e($transactions->longitude); ?>])
            .addTo(map)
            .bindPopup('Order Location')
            .openPopup();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/transactions/viewOrder.blade.php ENDPATH**/ ?>