<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create MilkTea Size-MilkTea Relationship')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-8">
        <form action="<?php echo e(route('milkteasize.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="milktea_id" class="block text-sm font-medium text-gray-600">MilkTea:</label>
                <select name="milktea_id" id="milktea_id" class="mt-1 p-2 border border-gray-300 rounded w-full">
                    <option value="<?php echo e($milkteaName->name); ?>"><?php echo e($milkteaName->name); ?></option>
                </select>
                <input type="hidden" name="milktea_id_hidden" id="milktea_id_hidden" value="<?php echo e($milkteaName->id); ?>">
            </div>
            <div class="mb-4">
                <label for="milktea_size_id" class="block text-sm font-medium text-gray-600">MilkTea Size:</label>
                <select name="milktea_size_id" id="milktea_size_id" class="mt-1 p-2 border border-gray-300 rounded w-full"></select>
            </div>
            <div class="mt-4">
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Create Size</button>
            </div>
        </form>
    </div>

    <script>
        const milkteaDropdown = document.getElementById('milktea_id');
        const milkteaSizeDropdown = document.getElementById('milktea_size_id');
        const milkteaSizeOptions = <?php echo json_encode($milkteaSize); ?>;

        function filterMilkteaSize() {
            const selectedMilktea = milkteaDropdown.value.toLowerCase();
            const filteredOptions = milkteaSizeOptions.filter(option => option.name.toLowerCase().includes(selectedMilktea));

            milkteaSizeDropdown.innerHTML = '';
            filteredOptions.forEach(option => {
                const newOption = document.createElement('option');
                newOption.value = option.id;
                newOption.textContent = option.name;
                milkteaSizeDropdown.appendChild(newOption);
            });
        }

        // Initial filter on page load
        filterMilkteaSize();

        milkteaDropdown.addEventListener('change', function() {
            const selectedMilkteaId = this.value;
            document.getElementById('milktea_id_hidden').value = selectedMilkteaId;
            filterMilkteaSize();
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea/milkteasize/newsize.blade.php ENDPATH**/ ?>