<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage MilkTea')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <?php $__env->startSection('content'); ?>
        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
            <div class="bg-green-200 text-green-800 p-4 mb-4 rounded-md">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            <h1 class="text-2xl font-semibold mb-6">Milk Teas</h1>
            <a href="<?php echo e(route('milktea.create')); ?>" class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition duration-300 ease-in-out mb-4 inline-flex items-center">
                <i class="fas fa-plus-circle text-xl mr-2"></i>
                New MilkTea
            </a>
            <table class="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $milkteas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milktea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($milktea->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($milktea->description); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($milktea->image): ?>
                                    <img src="data:image/png;base64,<?php echo e(base64_encode($milktea->image)); ?>" alt="Milk Tea Image" class="w-16 h-16 object-cover">
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            
                            
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="<?php echo e(route('milktea.show', $milktea)); ?>" class="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded transition duration-300 ease-in-out">
                                    Manage Size/Info
                                </a>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea/index.blade.php ENDPATH**/ ?>