<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Milktea Size Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-3xl font-semibold mb-6"><?php echo e($milkteaSize->name); ?></h1>
                    <p class="text-lg mb-4">Price: P <?php echo e(number_format($milkteaSize->price, 2)); ?></p>
                    <?php if($milkteaSize->created_at): ?>
                        <p class="text-lg mb-4">Created At: <?php echo e($milkteaSize->created_at->toFormattedDateString()); ?></p>
                    <?php else: ?>
                        <p class="text-lg mb-4">Created At: N/A</p>
                    <?php endif; ?>
                    <!-- Add more details as needed -->
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea_price/show.blade.php ENDPATH**/ ?>