<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Categories MilkTea')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('content'); ?>
        <h1 class="text-2xl font-semibold mb-4">Milk Tea Categories</h1>
        <a href="<?php echo e(route('milktea.categories.create')); ?>" class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition duration-300 ease-in-out mb-4 inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 inline-block -mt-1 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
            </svg>
            Add Category
        </a>
        <table class="min-w-full divide-y divide-gray-200">
            <thead>
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Last Updated</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                    
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($category->name); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($category->description); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php echo e(\Carbon\Carbon::parse($category->updated_at)->diffForHumans()); ?>

                        </td>
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="<?php echo e(route('milktea.categories.edit', $category)); ?>" class="bg-indigo-500 hover:bg-indigo-700 text-white py-2 px-4 rounded-full focus:outline-none focus:ring focus:ring-indigo-300">
                                Edit
                            </a>
                            <form action="<?php echo e(route('milktea.categories.destroy', $category)); ?>" method="POST" class="inline" id="delete-form-<?php echo e($category->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" onclick="confirmDelete('<?php echo e($category->id); ?>')" class="bg-red-500 hover:bg-red-700 text-white py-2 px-4 rounded-full focus:outline-none focus:ring focus:ring-red-300">
                                    Delete
                                </button>
                            </form>
                        </td>
                        
                        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<style>
    .swal2-popup {
        width: 400px; /* Adjust the width as needed */
        height: auto; /* You can set a specific height if required */
        padding: 20px;
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function confirmDelete(categoryId) {
        Swal.fire({
            title: 'Delete Category',
            text: 'Are you sure you want to delete this category?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                // User confirmed, proceed with deletion
                document.getElementById('delete-form-' + categoryId).submit();
            }
        });
    }
</script>
<?php /**PATH C:\Users\USER\Desktop\midterm\resources\views/milktea/categories/index.blade.php ENDPATH**/ ?>